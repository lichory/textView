//
//  TextViewCell.m
//  textView自适应
//
//  Created by apple on 15/7/24.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "TextViewCell.h"


@implementation TextViewCell

- (void)dealloc {
    
    [_nameLabel release];
    [_textView release];
    [_frameModel release];
    [super dealloc];
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        _nameLabel = [[UILabel alloc]init];
        [self.contentView addSubview:_nameLabel];
        
        _textView = [[UITextView alloc]init];
        _textView.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_textView];
        
    }
    return self;
}


- (void)setFrameModel:(FrameModel *)frameModel {
    [frameModel retain];
    [_frameModel release];
    _frameModel = frameModel;
    
    self.textView.text  = frameModel.model.content;
    self.textView.frame = frameModel.contentFrame;
    
    self.nameLabel.text = frameModel.model.name;
    self.nameLabel.frame = frameModel.nameFrame;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
