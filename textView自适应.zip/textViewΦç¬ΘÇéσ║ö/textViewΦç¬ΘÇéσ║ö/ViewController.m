//
//  ViewController.m
//  textView自适应
//
//  Created by apple on 15/7/24.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "ViewController.h"
#import "TextViewCell.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,UITextViewDelegate>

@property (nonatomic,assign)UITableView * tableView;

@property (nonatomic,retain) NSMutableArray * dataArr;
@property (nonatomic,retain) NSMutableArray * textHeightArr;

typedef void (^TextViewBlock)(NSIndexPath * indexPath);
@property (nonatomic,copy)TextViewBlock textViewBlock;

@property (nonatomic,assign) NSInteger currentIndex; // 当前编辑的cell

@end

@implementation ViewController

- (void)dealloc {
    
    [_textHeightArr release];
    [_tableView release];
    [_dataArr release];
    
    [super dealloc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _dataArr = [[NSMutableArray alloc]init];
    for (NSInteger i = 0; i<20; i++) {
        Model * model = [[Model alloc]init];
        model.name = @(i).description;
        model.content = @"";
        FrameModel * frame = [[FrameModel alloc]init];
        frame.model = model;
        [model release];
        [_dataArr addObject:frame];
        [frame release];
    }
    self.currentIndex = -1;
    _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClick)];
    [self.view addGestureRecognizer:tap];
    [tap release];
    
    
    
}

/**
 *
 *  通知，如果控制器VC的通知，只是作用在本类中，那么通知应该写在
 * - (void)viewWillAppear:(BOOL)animated
 * - (void)viewWillDisappear:(BOOL)animated
 * 这样的好处是不影响其他的类
 */
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

// 键盘

-(void)keyboardChange:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    CGRect keyboardEndFrame;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    
    [UIView animateWithDuration:animationDuration/2.0 animations:^{
        // 显示
        CGFloat heighOfOffY = 0;
        if (notification.name == UIKeyboardWillShowNotification) {
            heighOfOffY = keyboardEndFrame.size.height + 1;
            
        }else {// 隐藏
            heighOfOffY = 0;
        }
        UIEdgeInsets e = UIEdgeInsetsMake(0, 0, heighOfOffY, 0);
        // top, left, bottom, right（逆时针）
        [self.tableView setContentInset:e];// 相当于 tableView 的 底部提高了 一个键盘的 高度
        //[self.tableView setScrollIndicatorInsets:e];//调整滑动条距离窗口底边的距离

        if (self.currentIndex >= 0) {
            [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.currentIndex inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        }
        
    }];
    
}



- (void) tapClick {
    
    [self.view endEditing:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _dataArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [_dataArr[indexPath.row] heightOfCell];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    TextViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"TextViewCell"];
    if (!cell) {
        cell = [[[TextViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"TextViewCell"]autorelease];
        cell.nameLabel.backgroundColor = [UIColor blueColor];
        cell.textView.backgroundColor = [UIColor yellowColor];
        cell.textView.scrollEnabled = NO;
        cell.textView.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5);
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textView.delegate = self;
    }
    cell.textView.tag = indexPath.row;
    cell.frameModel = _dataArr[indexPath.row];
    return cell;
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    self.currentIndex = textView.tag;
    return YES;
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView {
    self.currentIndex = -1;
    return YES;
}
- (void)textViewDidChange:(UITextView *)textView {
    
    CGSize  textVSize = getTextSize1(textView.font, textView.text, 200);
    FrameModel * frameModel = _dataArr[textView.tag] ;
    Model * model = frameModel.model;
    if (textVSize.height != frameModel.heightOfTextView) {
        
        model.content = textView.text;
        frameModel.model = model;
        
        CGRect frame = textView.frame;
        frame.size.height =  textVSize.height;
        textView.frame = frame;
        //用改方法刷新=》键盘会一直在
        [self.tableView beginUpdates];
        [self.tableView endUpdates];
       
    }
}



CGSize getTextSize1(UIFont *font,NSString *text, CGFloat maxWidth){
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        
        CGSize textSize = [text boundingRectWithSize:CGSizeMake(maxWidth, MAXFLOAT)
                                             options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                                          attributes:@{NSFontAttributeName: font}
                                             context:nil].size;
        return textSize;
    }else{
        
        CGSize textSize = [text sizeWithFont:font
                           constrainedToSize:CGSizeMake(maxWidth, MAXFLOAT)
                               lineBreakMode:NSLineBreakByCharWrapping];
        return textSize;
        
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
