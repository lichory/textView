//
//  FrameModel.h
//  textView自适应
//
//  Created by apple on 15/7/24.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Model.h"

#define TextViewFont [UIFont systemFontOfSize:14]

@interface FrameModel : NSObject

@property (nonatomic,assign) CGRect  nameFrame;
@property (nonatomic,assign) CGRect  contentFrame;
@property (nonatomic,retain) Model * model;

@property (nonatomic,assign) CGFloat heightOfCell;
@property (nonatomic,assign) CGFloat heightOfTextView;

@end
