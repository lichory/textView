//
//  FrameModel.m
//  textView自适应
//
//  Created by apple on 15/7/24.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "FrameModel.h"

@implementation FrameModel

- (void)dealloc {
    
    [_model release];
    [super dealloc];
}

- (void)setModel:(Model *)model {
    
    
    [model retain];
    [_model release];
    _model = model;
    
    CGFloat space = 10;
    CGFloat nameX = space;
    CGFloat nameY = space;
    
    CGFloat nameW = 30;
    CGFloat nameH = 20;
    _nameFrame = CGRectMake(nameX, nameY, nameW, nameH);
    
    CGFloat textVX = CGRectGetMaxX(_nameFrame) + space;
    CGFloat textVY = space;
    CGFloat textVW = 200;
    CGSize  textVSize = getTextSize(TextViewFont, model.content, 200);
    CGFloat textVH = textVSize.height;
    _contentFrame = CGRectMake(textVX, textVY, textVW, textVH);
    
    self.heightOfCell = MAX(CGRectGetMaxY(_nameFrame), CGRectGetMaxY(_contentFrame)) + space;
    
    self.heightOfTextView = textVH;
    
}


CGSize getTextSize(UIFont *font,NSString *text, CGFloat maxWidth){
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        
        CGSize textSize = [text boundingRectWithSize:CGSizeMake(maxWidth, MAXFLOAT)
                                             options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                                          attributes:@{NSFontAttributeName: font}
                                             context:nil].size;
        return textSize;
    }else{
        
        CGSize textSize = [text sizeWithFont:font
                           constrainedToSize:CGSizeMake(maxWidth, MAXFLOAT)
                               lineBreakMode:NSLineBreakByCharWrapping];
        return textSize;
        
    }
}




@end
