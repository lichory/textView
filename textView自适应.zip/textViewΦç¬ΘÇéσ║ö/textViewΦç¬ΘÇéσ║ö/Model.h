//
//  Model.h
//  textView自适应
//
//  Created by apple on 15/7/24.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

@property (nonatomic,copy) NSString * name;
@property (nonatomic,copy) NSString * content;

@end
